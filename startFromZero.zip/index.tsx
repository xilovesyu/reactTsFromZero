import 'core-js/stable'
import 'regenerator-runtime/runtime'
import ReactDOM from 'react-dom'
import * as React from 'react'
import {Index} from './src/components'

ReactDOM.render(<Index />, document.getElementById('container'))
